public class HomeWorkJava1 {
    public static void main(String[] args) {
        printColor();}
    public static void printColor() {
        int value = 99;
        if (value <= 0) {
            System.out.println("Красный");
        }
        if (value > 0 & value <= 100) {
            System.out.println("Жёлтый");
        }
        if (value > 100) {
            System.out.println("Зелёный");
        }
    }
    }

