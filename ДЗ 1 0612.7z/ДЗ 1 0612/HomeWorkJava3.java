public class HomeWorkJava3 {
    public static void main(String[] args) {
        compareNumbers();}
    public static void compareNumbers() {
        int a = 5;
        int b = 5;
        if (a >= b) {
            System.out.println("a >= b");
        }
        if (a < b) {
            System.out.println("a < b");
        }
    }
}
