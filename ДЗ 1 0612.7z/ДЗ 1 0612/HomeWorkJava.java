public class HomeWorkJava {
    public static void main(String[] args) {
       System.out.println("Orange");
       System.out.println("Banana");
       System.out.println("Apple");
     }
   }

